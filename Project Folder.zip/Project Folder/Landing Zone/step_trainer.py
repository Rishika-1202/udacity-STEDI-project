import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Script generated for node Amazon S3 (step_trainer landing)
AmazonS3_node1767363390042 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiLine": "false"},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://project-create/step_trainer/landing/"], "recurse": True},
    transformation_ctx="AmazonS3_node1767363390042"
)

# Script generated for node Amazon S3 (customer trusted)
AmazonS3_node1767363525595 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiLine": "false"},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://project-create/customer/trusted/"], "recurse": True},
    transformation_ctx="AmazonS3_node1767363525595"
)

# Script generated for Join
Join_node1767363593787 = Join.apply(
    frame1=AmazonS3_node1767363390042,
    frame2=AmazonS3_node1767363525595,
    keys1=["serialNumber"],
    keys2=["serialNumber"],
    transformation_ctx="Join_node1767363593787"
)

# Script generated for Drop Fields
DropFields_node1767364355480 = DropFields.apply(
    frame=Join_node1767363593787,
    paths=["`.serialNumber`", "shareWithPublicAsOfDate", "birthDay",
           "registrationDate", "shareWithResearchAsOfDate", "customerName",
           "shareWithFriendsAsOfDate", "email", "lastUpdateDate", "phone"],
    transformation_ctx="DropFields_node1767364355480"
)

# Data Quality Evaluation
EvaluateDataQuality().process_rows(
    frame=DropFields_node1767364355480,
    ruleset=DEFAULT_DATA_QUALITY_RULESET,
    publishing_options={
        "dataQualityEvaluationContext": "EvaluateDataQuality_node1767363359839",
        "enableDataQualityResultsPublishing": True
    },
    additional_options={
        "dataQualityResultsPublishing.strategy": "BEST_EFFORT",
        "observations.scope": "ALL"
    }
)

# Script generated for node Amazon S3 (Trusted)
AmazonS3_node1767364397509 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1767364355480,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://project-create/step_trainer/trusted/",
        "partitionKeys": [],
        
        # ⭐ REQUIRED BY REVIEWER
        "enableUpdateCatalog": True,
        "updateCatalog": {
            "database": "project_db",
            "tableName": "step_trainer_trusted"
        }
    },
    transformation_ctx="AmazonS3_node1767364397509"
)

job.commit()
