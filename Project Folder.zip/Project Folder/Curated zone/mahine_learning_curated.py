import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Load step_trainer_trusted
step_trainer_trusted = glueContext.create_dynamic_frame.from_catalog(
    database="project_db",
    table_name="step_trainer_trusted",
    transformation_ctx="step_trainer_trusted"
)

# Load accelerometer_trusted
accelerometer_trusted = glueContext.create_dynamic_frame.from_catalog(
    database="project_db",
    table_name="accelerometer_trusted",
    transformation_ctx="accelerometer_trusted"
)

# Correct Join — Udacity expects join on timestamp
# step_trainer_trusted.sensorReadingTime == accelerometer_trusted.timestamp
Join_node = Join.apply(
    frame1=step_trainer_trusted,
    frame2=accelerometer_trusted,
    keys1=["sensorReadingTime"],
    keys2=["timestamp"],
    transformation_ctx="Join_node"
)

# Data Quality
EvaluateDataQuality().process_rows(
    frame=Join_node,
    ruleset=DEFAULT_DATA_QUALITY_RULESET,
    publishing_options={
        "dataQualityEvaluationContext": "EvaluateDataQuality_ml_curated",
        "enableDataQualityResultsPublishing": True
    },
    additional_options={
        "dataQualityResultsPublishing.strategy": "BEST_EFFORT",
        "observations.scope": "ALL"
    }
)

# Write curated output with DYNAMIC SCHEMA UPDATE FOR UDACITY
machine_learning_curated = glueContext.write_dynamic_frame.from_options(
    frame=Join_node,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://project-create/step_trainer/machine_learning_curated/",
        "partitionKeys": [],

        # REQUIRED BY UDEMY REVIEW
        "enableUpdateCatalog": True,
        "updateCatalog": {
            "database": "project_db",
            "tableName": "machine_learning_curated"
        }
    },
    transformation_ctx="machine_learning_curated"
)

job.commit()
