import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Source: Customer Landing Zone
customer_landing = glueContext.create_dynamic_frame.from_options(
    format_options={"multiLine": "false"},
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://project-create/customer/landing/"],
        "recurse": True
    },
    transformation_ctx="customer_landing"
)

# Privacy Filter → Remove rows with blank shareWithResearchAsOfDate
PrivacyFilter_node = Filter.apply(
    frame=customer_landing,
    f=lambda row: row["shareWithResearchAsOfDate"] is not None 
                  and row["shareWithResearchAsOfDate"] != "",
    transformation_ctx="PrivacyFilter_node"
)

# Data Quality Check
EvaluateDataQuality().process_rows(
    frame=PrivacyFilter_node,
    ruleset=DEFAULT_DATA_QUALITY_RULESET,
    publishing_options={
        "dataQualityEvaluationContext": "DQ_customer_trusted",
        "enableDataQualityResultsPublishing": True
    },
    additional_options={
        "dataQualityResultsPublishing.strategy": "BEST_EFFORT",
        "observations.scope": "ALL"
    }
)

# Write to Trusted Zone with Dynamic Schema Update Enabled
customer_trusted = glueContext.write_dynamic_frame.from_options(
    frame=PrivacyFilter_node,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://project-create/customer/trusted/",
        "partitionKeys": [],
        "updateBehavior": "UPDATE_IN_DATABASE",
        "catalogSchemaUpdate": "true",
        "catalogPartitionUpdate": "true",
        "enableUpdateCatalog": True
    },
    transformation_ctx="customer_trusted"
)

job.commit()
