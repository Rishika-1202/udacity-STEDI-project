import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Load accelerometer_trusted
accelerometertrusted_node1767366889704 = glueContext.create_dynamic_frame.from_catalog(
    database="project_db",
    table_name="accelerometer_trusted",
    transformation_ctx="accelerometertrusted_node1767366889704"
)

# Load customer_trusted
customertrusted_node1767366943475 = glueContext.create_dynamic_frame.from_catalog(
    database="project_db",
    table_name="customer_trusted",
    transformation_ctx="customertrusted_node1767366943475"
)

# Join customer_trusted with accelerometer_trusted
nodejoin_node1767366980379 = Join.apply(
    frame1=customertrusted_node1767366943475,
    frame2=accelerometertrusted_node1767366889704,
    keys1=["email"],
    keys2=["user"],
    transformation_ctx="nodejoin_node1767366980379"
)

# Drop unwanted fields
DropFields_node1767367469723 = DropFields.apply(
    frame=nodejoin_node1767366980379,
    paths=["z", "user", "y", "x", "timestamp"],
    transformation_ctx="DropFields_node1767367469723"
)

# Data Quality check
EvaluateDataQuality().process_rows(
    frame=DropFields_node1767367469723,
    ruleset=DEFAULT_DATA_QUALITY_RULESET,
    publishing_options={
        "dataQualityEvaluationContext": "EvaluateDataQuality_node1767366863993",
        "enableDataQualityResultsPublishing": True
    },
    additional_options={
        "dataQualityResultsPublishing.strategy": "BEST_EFFORT",
        "observations.scope": "ALL"
    }
)

# Write curated data with dynamic schema update ENABLED
AmazonS3_node1767367557996 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1767367469723,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://project-create/customer/curated/",
        "partitionKeys": [],
        "enableUpdateCatalog": True,  # REQUIRED BY UDACITY
        "updateCatalog": {
            "database": "project_db",
            "tableName": "customer_curated"
        }
    },
    transformation_ctx="AmazonS3_node1767367557996"
)

job.commit()
