import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality

args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Script generated for node source customer trusted
sourcecustomertrusted_node1767327534736 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiLine": "false"},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://project-create/customer/trusted/"], "recurse": True},
    transformation_ctx="sourcecustomertrusted_node1767327534736"
)

# Script generated for node source data accelerometer
sourcedataaccelerometer_node1767327504617 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiLine": "false"},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://project-create/accelerometer/landing/landing/"], "recurse": True},
    transformation_ctx="sourcedataaccelerometer_node1767327504617"
)

# Script generated for node Customer Privacy Filter
CustomerPrivacyFilter_node1767327844409 = Join.apply(
    frame1=sourcecustomertrusted_node1767327534736,
    frame2=sourcedataaccelerometer_node1767327504617,
    keys1=["email"],
    keys2=["user"],
    transformation_ctx="CustomerPrivacyFilter_node1767327844409"
)

# Script generated for node Drop Fields
DropFields_node1767328741591 = DropFields.apply(
    frame=CustomerPrivacyFilter_node1767327844409,
    paths=["email", "phone", "lastUpdateDate", "shareWithFriendsAsOfDate", "customerName",
           "registrationDate", "birthDay", "shareWithPublicAsOfDate", "serialNumber",
           "shareWithResearchAsOfDate", "timestamp"],
    transformation_ctx="DropFields_node1767328741591"
)

# Evaluate Data Quality
EvaluateDataQuality().process_rows(
    frame=DropFields_node1767328741591,
    ruleset=DEFAULT_DATA_QUALITY_RULESET,
    publishing_options={"dataQualityEvaluationContext": "EvaluateDataQuality_node1767327447462",
                        "enableDataQualityResultsPublishing": True},
    additional_options={"dataQualityResultsPublishing.strategy": "BEST_EFFORT", "observations.scope": "ALL"}
)

# Script generated for node Amazon S3 with dynamic schema update enabled
AmazonS3_node1767328751811 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1767328741591,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://project-create/accelerometer/trusted/",
        "partitionKeys": [],
        "updateBehavior": "UPDATE_IN_DATABASE",
        "catalogSchemaUpdate": "true",
        "catalogPartitionUpdate": "true",
        "enableUpdateCatalog": True
    },
    transformation_ctx="AmazonS3_node1767328751811"
)

job.commit()
